<?php
 include "conn.php";
 session_start();
 if(!isset($_SESSION["username"]))header("location: login.php");
 $id= $_GET['id'];

 $gambar=mysqli_query($conn,"SELECT * FROM pict where id_pict='$id'");
 $ambil=mysqli_fetch_array($gambar);
 echo "
 <form action='' method='POST' enctype='multipart/form-data'>
 <table>
 <tr>
 <td>
<input type='submit' name='index' value='Kembali ke halaman'>
 </td></tr>
 </table>
 <table>
 <tr>
 <td></td>
 <td><img src='$ambil[pict_path]' height='240' width='240'></img></td></tr>
 <tr><td></td></tr>
 </table>
 <table>
 <tr><td><textarea name='caps' cols='30' rows='0' placeholder='$ambil[capt]'></textarea></td>
 </tr>
 <tr>
 <td>
 <input type='submit' name='hapus' value='hapus gambar'>
 </td></tr>
 <tr>
 <td>
<input type='submit' name='edit' value='edit caption'>
 </td></tr>
 </table>
 </form>
 ";

 if(isset($_POST['hapus'])){
   $eks=  mysqli_query($conn,"DELETE FROM `pict` WHERE `id_pict` = '$id' ");
      $conn->query($eks);
      header("location:index.php?gambar-hapus");
 }
 if(isset($_POST['edit'])){
   $capt=$_POST['caps'];
  $ekss=  mysqli_query($conn,"UPDATE pict SET capt='$capt'  WHERE `id_pict` = '$id' ");
     $conn->query($ekss);
     header("location:index.php?gambar-edit");
}
if(isset($_POST['index'])){
    header("location:index.php");
}
 ?>