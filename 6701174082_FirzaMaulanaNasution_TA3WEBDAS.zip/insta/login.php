<?php
include("conn.php");
session_start();
if(isset($_SESSION["username"]))header("location: index.php");

if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $password=substr(md5($_POST['password']),0,8);
    $cek=mysqli_query($conn, "SELECT * FROM profil WHERE username='$username' AND password='$password' ");
        $data=mysqli_query($conn,"SELECT 'username' from profil where username='$username' ");
        $cekU=mysqli_fetch_assoc($data);
        $dats=mysqli_query($conn,"SELECT 'password' from profil where password='$password' ");
        $cekE=mysqli_fetch_assoc($dats);
    if(mysqli_num_rows($cek)>0){
        $hasil= mysqli_fetch_array($cek);
        $_SESSION['username'] = $hasil['username'];
        $_SESSION['password'] = $hasil['password'];
        $_SESSION['email']  = $hasil['email'];
        $_SESSION['nama'] = $hasil['nama'];
        $_SESSION['sapa'] = 1;

        header("location:index.php");
    }

    else{
        if($cekU&&!$cekE){
            echo"<script>alert('Password anda salah')</script>";

        }
        elseif(!$cekU&&$cekE){
            echo"<script>alert('Username anda salah')</script>";
        }
        else{
        echo"<script>alert('Anda Belum Terdaftar')</script>";

        }
    }
}



?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<form  method="post">
<table>
   <tr><td> Masukan Username :</td><td> <input type="text" name="username" required></td></tr>
   <tr><td> Masukan Password  :</td><td> <input type="password" name="password" required></td>
   <tr><td><input type="submit" name="submit" value="submit"></td></tr>
   <tr><td><a href="registrasi.php">Daftar akun ?</a></td></tr>
    </table></form>

</body>
</html>
<?php
mysqli_close($conn);
?>