<?php
include("conn.php");
session_start();
if(!isset($_SESSION["username"]))header("location: login.php");
$nama= $_SESSION['nama'];

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<?php
if(isset($_SESSION['sapa'])){
echo"<script>alert('Halo $nama')</script>";
unset($_SESSION['sapa']);
}
if(isset($_GET['gambar-hapus'])){
    echo"<script>alert('Gambar dihapus')</script>";
}
if(isset($_GET['gambar-up'])){
    echo"<script>alert('Gambar ditambah')</script>";
}
if(isset($_GET['gambar-edit'])){
    echo"<script>alert('Caption diedit')</script>";
}
?>
<table id="fungsi">
<form action="up.php">
<tr><td><input type="submit" name="upload" value="upload"></td></tr>
</form>
<form action="logout.php">
<tr><td><input type="submit" name="logout" value="logout"></td></tr>
</form>
</table>

<form>
<table>
   <tr><td><h2><?php echo ucfirst($nama)." Galleries"?></h2></td></td></tr>
    <?php
    $username=$_SESSION['username'];
    $data=mysqli_query($conn,"SELECT * from pict where username='$username'");
$no=1;
    while($hasil=mysqli_fetch_array($data)){ 
        $no++;

        echo "
        <td><a href='del.php?id=".$hasil['id_pict']."'><img src='$hasil[pict_path]' height='240' width='240'></img></a><br>$hasil[capt]</td>
      
        ";
        
        if($no>5){
            echo"<tr></tr>";
            $no=1;
        }
    }
    ?>

</table></form>

</body>
</html>
<?php
mysqli_close($conn);
?>