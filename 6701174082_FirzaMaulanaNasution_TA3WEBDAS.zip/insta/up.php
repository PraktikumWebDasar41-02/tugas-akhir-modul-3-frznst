<?php
include("conn.php");
session_start();
if(!isset($_SESSION["username"]))header("location: login.php");
if (isset($_POST['upload'])){
    $username=$_SESSION['username'];
    $capt = $_POST['caption'];
    $target_dir = "img/";
    $target_file = $target_dir. basename($_FILES["img"]["name"]);
      mysqli_query($conn,"INSERT INTO pict( pict_path, capt,username) values ( '$target_file', '$capt','$username')");
      header("location:index.php?gambar-up");
    }
if(isset($_GET['index'])){
    header("location:index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<form action="" method="get">
<table id="ups">
<tr>
 <td>
<input type='submit' name='index' value='Kembali ke halaman'>
 </td></tr>
 </table>
</form>

<table>
<form action="up.php" enctype="multipart/form-data" method="post">
<tr><td>Masukan Gambar</td></tr>
<tr><td><input type="file" name="img"></td></tr>
<tr><td>Masukan Caption</td></tr>
<tr><td><textarea name="caption" cols="30" rows="10"></textarea></td></tr>
<tr><td><input type="submit" name="upload" value="upload"></td></tr>
</table>
</form>

</body>
</html>
<?php
mysqli_close($conn);
?>