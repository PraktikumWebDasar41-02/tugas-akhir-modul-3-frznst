<?php
 $conn = mysqli_connect("localhost","root","","insta");
if(!$conn){
    die("Gagal Konek ".mysqli_connect_error());
}







?>