<?php
include("conn.php");

    if(isset($_POST['submit'])){
        $username=$_POST['username'];
        $email=$_POST['email'];
        $name=$_POST['nama'];
        $password=md5($_POST['password']);
        $data=mysqli_query($conn,"SELECT 'username' from profil where username='$username' ");
        $cekU=mysqli_fetch_assoc($data);
        $dats=mysqli_query($conn,"SELECT 'email' from profil where email='$email' ");
        $cekE=mysqli_fetch_assoc($dats);
        if(!$cekU&&!$cekE){
            mysqli_query($conn,"INSERT INTO profil  VALUES ('$username','$password','$name','$email')");
            header("location:login.php");
            echo"ha;pp";
        }
        elseif($cekU&&!$cekE){
            echo"<script>alert('Username sudah ada')</script>";
        }
        elseif(!$cekU&&$cekE){
            echo"<script>alert('Email sudah ada')</script>";
        }
        else{
            echo"<script>alert('Email dan Username sudah ada')</script>";
        }
 
    }


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<form  method="post">
<table>
   <tr><td> Masukan Username :</td><td> <input type="text" name="username" required></td></tr>
   <tr><td> Masukan Password  :</td><td> <input type="password" name="password" required></td>
   <tr><td>Masukan Nama     : </td><td><input type="text" name="nama" required></td></tr>
   <tr><td>Masukan Email    :</td><td> <input type="email" name="email" required></td></tr>
   <tr><td><input type="submit" name="submit" value="submit"></td></tr>
    </table></form>

</body>
</html>
<?php
mysqli_close($conn);
?>